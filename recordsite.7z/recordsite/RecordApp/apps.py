from django.apps import AppConfig


class RecordappConfig(AppConfig):
    name = 'RecordApp'
