from django.urls import path
from .api import records_api
from .static.js import *


from . import views



urlpatterns = [
    path('records/', views.records, name='records'),
    path('records/Display/', records_api.Display, name='Display'),
    path('records/deleteRecord/', records_api.deleteRecord, name='deleteRecord'),


]

