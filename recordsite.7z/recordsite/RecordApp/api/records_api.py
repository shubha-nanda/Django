from RecordApp.models import Registration
import json
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import redirect

@csrf_exempt
def Display(request):
        if request.method == "POST":
                Register = Registration.objects.create(
                        FirstName = json.loads(request.body)['FirstName'],
                        LastName = json.loads(request.body)['LastName'],
                        Mobile = json.loads(request.body)['Mobile'],
                        City = json.loads(request.body)['City'],
                        State = json.loads(request.body)['State']
                        )
                Register.save()         
                return allRecords()      




def allRecords():
        collegesData = Registration.objects.all()
        collegesList= []
        for college in collegesData:
                collegeData = {}
                collegeData['FirstName'] = college.FirstName
                collegeData['LastName'] = college.LastName
                collegeData['Mobile'] = college.Mobile
                collegeData['City'] = college.City
                collegeData['State'] =  college.State 
                collegesList.append(collegeData)
                
        return HttpResponse(json.dumps(collegesList))    

@csrf_exempt
def Update(request):
    if request.method == 'POST':
        RecordsData = Registration.objects.filter(
            id = json.loads(request.body)["id"]
            ).update(
            FirstName = json.loads(request.body)["FirstName"],
            LastName = json.loads(request.body)["LastName"],
            Mobile =  json.loads(request.body)["Mobile"],
            City = json.loads(request.body)["City"],
            State = json.loads(request.body)["State"]           
            )
        RecordsData.save()
            
        return allRecords()

@csrf_exempt
def deleteRecord(request):
    if request.method == 'POST':
        Registration.objects.filter(FirstName=json.loads(request.body)['FirstName']).delete()        
        return allRecords()
